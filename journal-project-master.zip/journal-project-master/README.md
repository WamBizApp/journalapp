## Gratitude journal

Full stack app project for Thinkful
