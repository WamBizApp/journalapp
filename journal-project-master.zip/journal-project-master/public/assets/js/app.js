$(function() {
    // getAndDisplayEntries();
    displayEntries();
})

function getRecentEntries(callback) {
    setTimeout(function(){callback(MOCK_ENTRIES)}, 100);
}

function displayEntries(data) {
  let url = '/mockdata';
  $.ajax({
   type: "GET",
   url: url,
   contentType: 'application/json',
   success: function(data) {
     console.log(data);
   }
});


    // for (index in data.entries) {
    //    $('ol').append(
    //     '<h3>Date:</h3>' +
    //     '<p>' + data.entries[index].date + '</p>' +
    //     '<div>'+
    //     '<h3>Three things I am grateful for today:</h3>' +
    //     // '<ol>' +
    //     '<li>' + data.entries[index].content.grateful.one + '</li>' +
    //     '<li>' + data.entries[index].content.grateful.two + '</li>' +
    //     '<li>' + data.entries[index].content.grateful.three + '</li>' +
    //     // '</ol>' +
    //     '</div>' +
    //     '<h3>What could I have done differently today?</h3>' +
    //     '<p>' + data.entries[index].content.improveForOthers + '</p>' +
    //     '<h3>How did I try to improve someone elses day today?</h3>' +
    //     '<p>' + data.entries[index].content.differentlyToday + '</p>' +
    //     '<h3>One goal for tomorrow:</h3>' +
    //     '<p>' + data.entries[index].content.goalTomorrow + '</p>');
    // }
}

function getAndDisplayEntries() {
    getRecentEntries(displayEntries);
}
