let moment = require('moment');

let MOCK_ENTRIES = {
  "entries": [{
      "id": 111,
      "date": moment(Date.now()).format("l"),
      "content": {
        "grateful": {
          "one": "birds flying high",
          "two": "sun in the sky",
          "three": "Reeds drifting on by",
        },
        "improveForOthers": "new dawn",
        "differentlyToday": "new day",
        "goalTomorrow": "new life"
      },
      "author": "Katie",
    },
    {
      "id": 222,
      "date": moment(Date.now()).format("l"),
      "content": {
        "grateful": {
          "one": "pterosaurs flying high",
          "two": "meteros in the sky",
          "three": "twigs drifting on by",
        },
        "improveForOthers": "stars when you shine",
        "differentlyToday": "scent of the pine",
        "goalTomorrow": "freedom is mine"
      },
      "author": "Katie",
    },
    {
      "id": 333,
      "date": moment(Date.now()).format("l"),
      "content": {
        "grateful": {
          "one": "butterflies flying high",
          "two": "UFO in the sky",
          "three": "leaves drifting on by",
        },
        "improveForOthers": "dragonfly out in the sun",
        "differentlyToday": "old world",
        "goalTomorrow": "bold world"
      },
      "author": "Katie",
    },
  ]
};

exports.MOCK_ENTRIES = MOCK_ENTRIES
