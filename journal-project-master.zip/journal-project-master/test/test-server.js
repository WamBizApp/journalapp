
const chai = require('chai');
const chaiHttp = require('chai-http');
const server = require('../server.js');

const should = chai.should();
const app = server.app;

chai.use(chaiHttp);


describe('entries end-point', function() {
  it('should have status 200 and return html', function() {
    return chai.request(app)
    .get('/entries.html')
    .then(function(res) {
      res.should.have.status(200);
      res.should.be.html;
    });
  });
});

//why does it have to be named index.html for the localhost:9000 to work?
describe('new-entry end-point', function() {
  it('should have status 200 and return html', function() {
    return chai.request(app)
    .get('/index.html')
    .then(function(res) {
      res.should.have.status(200);
      res.should.be.html;
    });
  });
});
