const mongoose = require('mongoose');

const entrySchema = mongoose.Schema(
} {
date: {
  type: Date,
  default: moment(Date.now()).format("l")
},
content: {
  grateful: {
    one: String,
    two: String,
    three: String,
  },
  improveForOthers: String,
  differentlyToday: String,
  goalTomorrow: String
},
author: String
})

entrySchema.methods.apiRepr = function {
  id: this._id,
  content: {
    grateful: {
      one: this.content.grateful.one,
      two: this.content.grateful.two,
      three: this.content.grateful.three,
    },
    improveForOthers: this.content.improveForOthers,
    differentlyToday: this.content.differentlyToday,
    goalTomorrow: this.content.goalTomorrow
  }
  author: this.author,
  date: this.date
}


const Entry = mongoose.model('Entry', entrySchema);

module.exports = {
  Entry
};
